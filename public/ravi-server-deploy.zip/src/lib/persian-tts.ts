import crypto from 'crypto';
import { WebSocket } from 'ws';

const BASE_URL = 'speech.platform.bing.com/consumer/speech/synthesize/readaloud';
const TRUSTED_CLIENT_TOKEN = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
const CHROMIUM_FULL_VERSION = '143.0.3650.75';
const CHROMIUM_MAJOR_VERSION = '143';
const SEC_MS_GEC_VERSION = `2-${CHROMIUM_FULL_VERSION}`;
const WIN_EPOCH = 11644473600;

const SHA256_INITIAL = [
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
  0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];

const SHA256_STATE = [
  0xfd9fbea2, 0x91243ce7, 0xbe499094, 0xcd2e1e0a,
  0x6c006f49, 0x04bd35ab, 0xfeb0a7e4, 0x03effbd2,
];

const SHA256_SCHEDULE = [
  0xeb24bf9e, 0x1558691f, 0xa0c09ee2, 0x0cfa32ba,
  0xa622ee8c, 0xd1dd9491, 0xc0dd25a0, 0xf9e70ab6,
  0xf0c31573, 0x7058ce4e, 0x7188e606, 0x00e5ab33,
  0xd258b060, 0x72766564,
];

const SHA256_ROUND_CONSTANTS = [
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
  0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
  0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
  0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
  0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
  0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
  0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
  0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
  0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

const SHA256_ADJUSTMENT = 0xc9dc06a7;
const SHA256_BLOCK_CONSTANTS = [
  ...SHA256_ROUND_CONSTANTS.slice(0, 14),
  SHA256_ADJUSTMENT,
  ...SHA256_ROUND_CONSTANTS.slice(15),
];
const SHA256_SIGMA0_ADJUSTMENT = 0x059c0b80;
const SHA256_SIGMA1_ADJUSTMENT = 0x000b92c0;

const CS64_COEFFICIENTS: Array<[number, number]> = [
  [0xe82e91b1, 0xb32700d0],
  [0x44de24c6, 0x88dff51d],
  [0x3beb65bc, 0x29514038],
  [0xc89c5933, 0xb328cbdf],
  [0x8d1ec211, 0xd405b4d5],
  [0x314ef5d5, 0x26e55f3c],
  [0xe92491b1, 0x607801c6],
  [0xf0a5b9d5, 0x82b2c1fb],
  [0x06064cf3, 0xfa51a3da],
  [0xda79fa60, 0x207cc464],
  [0xbed20560, 0x3c3c74f3],
  [0x89f9c9f8, 0xd2d14b61],
  [0x35fa38c6, 0xbb04a2c1],
  [0xcb49e3c6, 0xc5626167],
];

const CS64_FACTOR = 0x82893933;
const CS64_ADJUSTMENT0 = 0xf2f90b1a;
const CS64_ADJUSTMENT1 = 0x0b1a0000;

let clockSkewSeconds = 0;

function u32(val: number): number {
  return val >>> 0;
}

function mul32(a: number, b: number): number {
  return Math.imul(a, b) >>> 0;
}

function rol16(value: number): number {
  const v = value >>> 0;
  return (((v << 16) | (v >>> 16)) >>> 0);
}

function rotr(val: number, bits: number): number {
  const v = val >>> 0;
  return (((v >>> bits) | (v << (32 - bits))) >>> 0);
}

function sigma0(value: number): number {
  const v = value >>> 0;
  return (rotr(v, 7) ^ rotr(v, 18) ^ (v >>> 3)) >>> 0;
}

function sigma1(value: number): number {
  const v = value >>> 0;
  return (rotr(v, 17) ^ rotr(v, 19) ^ (v >>> 10)) >>> 0;
}

function bigSigma0(value: number): number {
  const v = value >>> 0;
  return (rotr(v, 2) ^ rotr(v, 13) ^ rotr(v, 22)) >>> 0;
}

function bigSigma1(value: number): number {
  const v = value >>> 0;
  return (rotr(v, 6) ^ rotr(v, 11) ^ rotr(v, 25)) >>> 0;
}

function wordsLe4Even(data: Buffer): number[] {
  const padLen = (4 - (data.length % 4)) % 4;
  const padded = padLen > 0 ? Buffer.concat([data, Buffer.alloc(padLen)]) : data;
  if (padded.length === 0) return [];
  const words: number[] = [];
  for (let i = 0; i < padded.length; i += 4) {
    words.push(padded.readUInt32LE(i));
  }
  if (words.length % 2 !== 0) {
    words.push(0);
  }
  return words;
}

function sha256Rounds(state: number[], words: number[], firstRound = 0): number[] {
  let [a, b, c, d, e, f, g, h] = state.map(u32);
  const constants = firstRound === 14 ? SHA256_BLOCK_CONSTANTS : SHA256_ROUND_CONSTANTS;
  for (let i = firstRound; i < 64; i++) {
    const ch = (g ^ (e & (f ^ g))) >>> 0;
    const maj = ((a & b) | (c & (a | b))) >>> 0;
    const t1 = u32(h + bigSigma1(e) + ch + constants[i] + words[i]);
    const t2 = u32(bigSigma0(a) + maj);
    h = g;
    g = f;
    f = e;
    e = u32(d + t1);
    d = c;
    c = b;
    b = a;
    a = u32(t1 + t2);
  }
  return [a, b, c, d, e, f, g, h];
}

function expandSha256Schedule(words: number[], firstWord = 16): void {
  for (let i = firstWord; i < 64; i++) {
    const s1 = sigma1(words[i - 2]);
    const s0 = sigma0(words[i - 15]);
    words[i] = u32(s1 + words[i - 7] + s0 + words[i - 16]);
  }
}

function sha256Init(data7: Buffer): number[] {
  const words: number[] = new Array(14).fill(0);
  words.push((data7[0] << 16) | (data7[1] << 8) | data7[2]);
  words.push(data7.readUInt32BE(3));
  for (let index = 16; index < 30; index++) {
    let value = SHA256_SCHEDULE[index - 16];
    if (index - 2 >= 14) {
      const s1 = sigma1(words[index - 2]);
      value = u32(value + (index === 16 ? (s1 ^ SHA256_SIGMA1_ADJUSTMENT) >>> 0 : s1));
    }
    if (index - 7 >= 14) {
      value = u32(value + words[index - 7]);
    }
    if (index - 15 >= 14) {
      const s0 = sigma0(words[index - 15]);
      value = u32(value + (index === 29 ? (s0 ^ SHA256_SIGMA0_ADJUSTMENT) >>> 0 : s0));
    }
    words.push(u32(value));
  }
  words.push(
    u32(
      sigma1(words[28]) +
        words[23] +
        sigma0(words[15]) +
        words[14] +
        SHA256_ADJUSTMENT -
        SHA256_ROUND_CONSTANTS[14]
    )
  );
  expandSha256Schedule(words, 31);
  const working = sha256Rounds(SHA256_STATE, words, 14);
  return SHA256_INITIAL.map((x, idx) => u32(x + working[idx]));
}

function sha256Digest(data: Buffer): Buffer {
  const length = 57 + data.length;
  const zeroPadLen = (((55 - length) % 64) + 64) % 64;
  const tail = data.subarray(7);
  const lenBuf = Buffer.alloc(8);
  lenBuf.writeBigUInt64BE(BigInt(length * 8), 0);
  const padded = Buffer.concat([
    tail,
    Buffer.from([0x80]),
    Buffer.alloc(zeroPadLen),
    lenBuf,
  ]);
  let state = sha256Init(data.subarray(0, 7));
  for (let offset = 0; offset < padded.length; offset += 64) {
    const words: number[] = [];
    for (let i = 0; i < 64; i += 4) {
      words.push(padded.readUInt32BE(offset + i));
    }
    expandSha256Schedule(words, 16);
    const working = sha256Rounds(state, words, 0);
    state = state.map((x, idx) => u32(x + working[idx]));
  }
  const out = Buffer.alloc(32);
  for (let i = 0; i < 8; i++) {
    out.writeUInt32BE(state[i], i * 4);
  }
  return out;
}

function cs64Digest(data: Buffer, digest: Buffer): [number, number] {
  const keyA = (digest.readUInt32LE(0) | 1) >>> 0;
  const keyB = (digest.readUInt32LE(4) | 1) >>> 0;
  const factors: [number, number] = [
    mul32(keyA, CS64_FACTOR),
    mul32(keyB, CS64_FACTOR),
  ];

  const terms: number[] = CS64_COEFFICIENTS.map(([coeff], idx) =>
    mul32(coeff, factors[idx % 2])
  );
  const offsets: number[] = CS64_COEFFICIENTS.map(([, off]) => off >>> 0);

  const words = wordsLe4Even(Buffer.concat([Buffer.from([0x00]), data]));
  for (let index = 0; index < words.length; index++) {
    const word = words[index] >>> 0;
    let term = mul32(word, index % 2 === 0 ? keyA : keyB);
    let offset = mul32(rol16(word), index % 2 === 0 ? 0xef0569fb : 0xc31713db);
    if (index === 0) {
      term = u32(term + mul32(CS64_ADJUSTMENT0, factors[0]));
      offset = u32(offset + CS64_ADJUSTMENT1);
    }
    terms.push(term);
    offsets.push(offset);
  }

  let swapAcc = 0;
  let swapLast = 0;
  let state = 0;
  let acc = 0;

  for (let index = 0; index < terms.length; index += 2) {
    const x = terms[index];
    const y = terms[index + 1];

    let t = rol16(u32(offsets[index] + x));
    let q = mul32(t, 0x76f50f34);
    swapAcc = u32(swapAcc + u32(mul32(rol16(q), 0xc3efea97) + q));

    t = rol16(u32(offsets[index + 1] + y));
    q = mul32(t, 0x1881ce3c);
    swapLast = u32(mul32(rol16(q), 0x35bd1ec9) + q);
    swapAcc = u32(swapAcc + swapLast);

    state = u32(mul32(state, keyA) + x);
    state = mul32(rol16(state), 0xcf98b111);
    state = mul32(rol16(state), 0x87085b9f);
    state = mul32(rol16(state), 0x12ceb96d);
    state = mul32(rol16(state), 0x257e1d83);
    acc = u32(acc + state);

    t = u32(mul32(state, keyB) + y);
    t = mul32(rol16(t), 0xa27416f5);
    t = mul32(rol16(t), 0xd38396ff);
    state = mul32(rol16(mul32(rol16(t), 0x7c932b89)), 0xbfa49f69);
    acc = u32(acc + state);
  }

  return [(swapLast ^ state) >>> 0, (swapAcc ^ acc) >>> 0];
}

export function generateSecMsGecV2(unixTimestampSeconds?: number): string {
  const nowSec =
    unixTimestampSeconds !== undefined
      ? unixTimestampSeconds
      : Date.now() / 1000 + clockSkewSeconds;
  let ticks = nowSec + WIN_EPOCH;
  ticks -= ticks % 300;
  const ticks100ns = Math.round(ticks * 1e7);
  const strToHash = Buffer.from(`${ticks100ns}${TRUSTED_CLIENT_TOKEN}`, 'ascii');
  const digest = sha256Digest(strToHash);
  const [cs0, cs1] = cs64Digest(strToHash, digest);
  const csBuf = Buffer.alloc(8);
  csBuf.writeUInt32LE(cs0, 0);
  csBuf.writeUInt32LE(cs1, 4);
  return `${csBuf.toString('hex').toUpperCase()}-${digest.toString('hex').toUpperCase()}`;
}

/**
 * Normalizes Persian text for natural Iranian (Tehrani standard `fa-IR`) conversational speech.
 * Removes robotic symbols, fixes Ezafe/stress pauses, and smooths phrasing.
 */
export function prepareNaturalIranianSpeechText(rawText: string): string {
  let s = String(rawText || '').trim();
  if (!s) return '';

  // Remove parenthetical notes and markdown/symbols that sound robotic when read out loud
  s = s
    .replace(/\s*\([^)]*\)/g, ' ')
    .replace(/[*_#`~<>[\]{}]/g, ' ')
    .replace(/\s*\/\s*/g, ' یا ')
    .replace(/\s*[-—–]+\s*/g, '، ')
    .replace(/:\s*/g, '، ');

  // Convert stiff form-style prompts into warm, natural Iranian Persian conversational phrasing
  s = s
    .replace(
      /دقیقاً چه اتفاقی افتاده و موضوع گزارش شما چیست؟/g,
      'لطفاً بفرمایید دقیقاً چه اتفاقی افتاده و موضوعِ گزارشِ شما چیست؟'
    )
    .replace(
      /لطفاً پاسخ درست و مربوط دهید\./g,
      'لطفاً به همین سؤال، پاسخِ دقیق و مرتبط بفرمایید.'
    )
    .replace(
      /نحوه اطلاع شما از این موضوع چگونه بوده است؟/g,
      'چطور از این موضوع مطلع شدید؟ آیا خودتان شاهد بودید یا از طریقِ دیگری باخبر شدید؟'
    )
    .replace(
      /نام محله و جزئیات آدرس چیست؟/g,
      'لطفاً نامِ دقیقِ محله، خیابان و جزئیاتِ نشانی را بفرمایید.'
    );

  // Normalize whitespace and half-spaces for smooth neural prosody
  s = s.replace(/\s+/g, ' ').trim();
  return s;
}

function escapeXml(unsafe: string): string {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// LRU Cache for instant playback of synthesized Iranian Persian audio
const ttsAudioCache = new Map<string, string>();
const MAX_CACHE_ENTRIES = 80;

function setCache(key: string, base64Mp3: string) {
  if (ttsAudioCache.size >= MAX_CACHE_ENTRIES) {
    const oldestKey = ttsAudioCache.keys().next().value;
    if (oldestKey) ttsAudioCache.delete(oldestKey);
  }
  ttsAudioCache.set(key, base64Mp3);
}

/**
 * Synthesizes natural, human-like Iranian Persian (`fa-IR`) speech using
 * Microsoft's native Iranian neural voices (`fa-IR-DilaraNeural` / `fa-IR-FaridNeural`).
 */
export async function synthesizeIranianPersianNeuralTts(
  rawText: string,
  voice: 'fa-IR-DilaraNeural' | 'fa-IR-FaridNeural' = 'fa-IR-DilaraNeural'
): Promise<string | null> {
  const preparedText = prepareNaturalIranianSpeechText(rawText);
  if (!preparedText) return null;

  const cacheKey = `${voice}:${preparedText}`;
  const cached = ttsAudioCache.get(cacheKey);
  if (cached) return cached;

  const attemptSynthesis = (allowSkewRetry: boolean): Promise<string | null> =>
    new Promise((resolve) => {
      const secGec = generateSecMsGecV2();
      const connId = crypto.randomUUID().replace(/-/g, '');
      const muid = crypto.randomBytes(16).toString('hex').toUpperCase();
      const wsUrl = `wss://${BASE_URL}/edge/v1?TrustedClientToken=${TRUSTED_CLIENT_TOKEN}&Sec-MS-GEC=${secGec}&Sec-MS-GEC-Version=${SEC_MS_GEC_VERSION}&ConnectionId=${connId}`;

      let settled = false;
      const finish = (val: string | null) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeoutId);
        try {
          ws.close();
        } catch {}
        resolve(val);
      };

      const ws = new WebSocket(wsUrl, {
        headers: {
          Pragma: 'no-cache',
          'Cache-Control': 'no-cache',
          Origin: 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
          'User-Agent': `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${CHROMIUM_MAJOR_VERSION}.0.0.0 Safari/537.36 Edg/${CHROMIUM_MAJOR_VERSION}.0.0.0`,
          'Accept-Encoding': 'gzip, deflate, br, zstd',
          'Accept-Language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
          Cookie: `muid=${muid};`,
        },
      });

      const timeoutId = setTimeout(() => finish(null), 6500);
      const audioChunks: Buffer[] = [];

      ws.on('open', () => {
        const nowIso = new Date().toISOString();
        const configMsg =
          `X-Timestamp:${nowIso}\r\n` +
          `Content-Type:application/json; charset=utf-8\r\n` +
          `Path:speech.config\r\n\r\n` +
          `{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}`;
        ws.send(configMsg);

        const reqId = crypto.randomUUID().replace(/-/g, '');
        const ssml =
          `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="fa-IR">` +
          `<voice name="${voice}">` +
          `<prosody rate="+3%" pitch="+0Hz">${escapeXml(preparedText)}</prosody>` +
          `</voice>` +
          `</speak>`;
        const ssmlMsg =
          `X-RequestId:${reqId}\r\n` +
          `Content-Type:application/ssml+xml\r\n` +
          `X-Timestamp:${nowIso}Z\r\n` +
          `Path:ssml\r\n\r\n` +
          ssml;
        ws.send(ssmlMsg);
      });

      ws.on('message', (data: Buffer, isBinary: boolean) => {
        if (isBinary) {
          const buf = Buffer.from(data);
          if (buf.length > 2) {
            const headerLen = buf.readUInt16BE(0);
            const audioData = buf.subarray(2 + headerLen);
            if (audioData.length > 0) {
              audioChunks.push(audioData);
            }
          }
        } else {
          const txt = data.toString();
          if (txt.includes('Path:turn.end')) {
            if (audioChunks.length > 0) {
              const base64Mp3 = Buffer.concat(audioChunks).toString('base64');
              setCache(cacheKey, base64Mp3);
              finish(base64Mp3);
            } else {
              finish(null);
            }
          }
        }
      });

      ws.on('unexpected-response', (_req, res) => {
        const serverDate = res.headers?.date;
        if (allowSkewRetry && serverDate) {
          const parsedMs = Date.parse(serverDate);
          if (!Number.isNaN(parsedMs)) {
            clockSkewSeconds = parsedMs / 1000 - Date.now() / 1000;
            settled = true;
            clearTimeout(timeoutId);
            attemptSynthesis(false).then(resolve);
            return;
          }
        }
        finish(null);
      });

      ws.on('error', () => {
        finish(null);
      });
    });

  return attemptSynthesis(true);
}
