import React, { useState, useMemo } from 'react';
import {
  Shield,
  FileText,
  Users,
  BarChart3,
  Search,
  Filter,
  CheckCircle,
  Clock,
  AlertTriangle,
  Download,
  LogOut,
  Printer,
  ChevronLeft,
  Calendar,
  Lock,
  Eye,
  RefreshCw,
  TrendingUp,
  Award,
} from 'lucide-react';
import { OfficialPdfReport } from './OfficialPdfReport.tsx';

interface AdminPanelProps {
  reports: any[];
  onUpdateReportStatus?: (id: string, status: string) => void;
  onExitAdmin?: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  reports: initialReports,
  onUpdateReportStatus,
  onExitAdmin,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return localStorage.getItem('faraja_admin_session') === 'true';
    } catch {
      return false;
    }
  });

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Admin tabs: 'monitoring' | 'performance' | 'analytics'
  const [tab, setTab] = useState<'monitoring' | 'performance' | 'analytics'>('monitoring');

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [provinceFilter, setProvinceFilter] = useState('all');

  // Modals
  const [selectedReportForPdf, setSelectedReportForPdf] = useState<any | null>(null);
  const [selectedReportDetails, setSelectedReportDetails] = useState<any | null>(null);

  // Local copy of reports with possible admin status overrides
  const [reportsList, setReportsList] = useState<any[]>(() => {
    try {
      const savedStatus = JSON.parse(localStorage.getItem('faraja_reports_status') || '{}');
      return initialReports.map((r) => ({
        ...r,
        status: savedStatus[r.id] || r.status || 'جدید',
      }));
    } catch {
      return initialReports.map((r) => ({ ...r, status: r.status || 'جدید' }));
    }
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim() === 'admin' && password === 'admin') {
      setIsAuthenticated(true);
      try {
        localStorage.setItem('faraja_admin_session', 'true');
      } catch {}
      setLoginError('');
    } else {
      setLoginError('نام کاربری یا کلمه عبور نادرست است. (نام کاربری: admin / کلمه عبور: admin)');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    try {
      localStorage.removeItem('faraja_admin_session');
    } catch {}
  };

  const handleStatusChange = (id: string, newStatus: string) => {
    const updated = reportsList.map((r) => (r.id === id ? { ...r, status: newStatus } : r));
    setReportsList(updated);
    try {
      const saved = JSON.parse(localStorage.getItem('faraja_reports_status') || '{}');
      saved[id] = newStatus;
      localStorage.setItem('faraja_reports_status', JSON.stringify(saved));
    } catch {}
    if (onUpdateReportStatus) {
      onUpdateReportStatus(id, newStatus);
    }
  };

  // Filtered reports
  const filteredReports = useMemo(() => {
    return reportsList.filter((r) => {
      const matchesSearch =
        !searchTerm ||
        r.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (r.title || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (r.text || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (r.reporter?.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (r.reporter?.rank || '').toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = statusFilter === 'all' || r.status === statusFilter;
      const matchesProvince = provinceFilter === 'all' || r.reporter?.province === provinceFilter;

      return matchesSearch && matchesStatus && matchesProvince;
    });
  }, [reportsList, searchTerm, statusFilter, provinceFilter]);

  // Performance calculations by reporter
  const reporterPerformance = useMemo(() => {
    const map = new Map<string, any>();

    reportsList.forEach((r) => {
      const key = r.reporter?.name ? `${r.reporter.name}_${r.reporter.mobile}` : 'نامشخص';
      if (!map.has(key)) {
        map.set(key, {
          name: r.reporter?.name || 'گزارش‌دهنده ناشناس',
          rank: r.reporter?.rank || 'یگان نامشخص',
          post: r.reporter?.post || '—',
          province: r.reporter?.province || 'تهران',
          mobile: r.reporter?.mobile || '—',
          reportsCount: 0,
          verifiedCount: 0,
          hasFilesCount: 0,
          qualityScoreSum: 0,
        });
      }

      const entry = map.get(key);
      entry.reportsCount += 1;
      if (r.status === 'اقدام‌شده' || r.status === 'مختومه') {
        entry.verifiedCount += 1;
      }
      if (r.files && r.files.length > 0) {
        entry.hasFilesCount += 1;
      }

      // Calculate quality score based on richness of answers
      const answersCount = Object.keys(r.answers || {}).length;
      const textLen = (r.text || '').length;
      let score = 70;
      if (answersCount >= 3) score += 15;
      if (textLen > 100) score += 10;
      if (r.files?.length) score += 5;
      entry.qualityScoreSum += Math.min(score, 100);
    });

    return Array.from(map.values()).map((p) => ({
      ...p,
      avgQuality: Math.round(p.qualityScoreSum / p.reportsCount),
      verificationRate: Math.round((p.verifiedCount / p.reportsCount) * 100),
      rankBadge:
        p.qualityScoreSum / p.reportsCount >= 90
          ? 'عالی'
          : p.qualityScoreSum / p.reportsCount >= 75
          ? 'خیلی خوب'
          : 'قابل قبول',
    }));
  }, [reportsList]);

  // Provinces list for filter
  const provinces = useMemo(() => {
    const set = new Set<string>();
    reportsList.forEach((r) => {
      if (r.reporter?.province) set.add(r.reporter.province);
    });
    return Array.from(set);
  }, [reportsList]);

  // Export CSV
  const exportCsv = () => {
    const headers = 'شناسه,تاریخ,عنوان,گزارش دهنده,رده,استان,تعداد مستندات,وضعیت\n';
    const rows = filteredReports
      .map(
        (r) =>
          `"${r.id}","${new Date(r.created || Date.now()).toLocaleDateString('fa-IR')}","${(r.title || '').replace(/"/g, '""')}","${r.reporter?.name || ''}","${r.reporter?.rank || ''}","${r.reporter?.province || ''}","${r.files?.length || 0}","${r.status || 'جدید'}"`
      )
      .join('\n');
    const blob = new Blob(['\uFEFF' + headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `faraja_reports_export_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // IF NOT AUTHENTICATED: Show Login Screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#f3f7f5] dark:bg-[#0a110d] flex items-center justify-center p-4 text-right font-vazir" dir="rtl">
        <div className="max-w-md w-full bg-white dark:bg-[#15221b] border border-[#d9e3dd] dark:border-[#22372c] rounded-3xl p-8 shadow-xl">
          <div className="flex flex-col items-center justify-center text-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-[#edf5f0] dark:bg-[#1a2f24] text-[#244b3b] dark:text-[#a0dbbf] flex items-center justify-center mb-3 shadow-inner">
              <Shield className="w-9 h-9" />
            </div>
            <h1 className="text-xl font-extrabold text-[#18372b] dark:text-[#e7eee9]">
              سامانه پایش و مدیریت گزارشات
            </h1>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              سازمان رزم سوم فراجا
            </p>
          </div>

          {loginError && (
            <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs rounded-xl mb-4 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">نام کاربری</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin"
                className="w-full bg-[#fcfdfa] dark:bg-[#0e1612] border border-[#d9e3dd] dark:border-[#284235] text-sm text-[#18372b] dark:text-[#e7eee9] rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-[#244b3b]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">کلمه عبور</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••"
                className="w-full bg-[#fcfdfa] dark:bg-[#0e1612] border border-[#d9e3dd] dark:border-[#284235] text-sm text-[#18372b] dark:text-[#e7eee9] rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-[#244b3b]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#244b3b] hover:bg-[#18372b] dark:bg-[#2c624c] dark:hover:bg-[#23503e] text-white rounded-xl text-xs font-bold shadow-md transition flex items-center justify-center gap-2"
            >
              <Lock className="w-4 h-4" />
              ورود به سامانه نظارت و گزارش‌گیری
            </button>
          </form>

          {onExitAdmin && (
            <div className="mt-6 text-center">
              <button
                type="button"
                onClick={onExitAdmin}
                className="text-xs text-[#244b3b] dark:text-[#a0dbbf] hover:underline"
              >
                بازگشت به سامانه ثبت گزارش مردمی
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f4f7f5] dark:bg-[#0d1611] text-[#18372b] dark:text-[#e7eee9] text-right font-vazir" dir="rtl">
      {/* Top Admin Header */}
      <header className="sticky top-0 z-40 bg-white dark:bg-[#15221b] border-b border-[#e1e9e4] dark:border-[#22372c] shadow-xs">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#edf5f0] dark:bg-[#1a2f24] text-[#244b3b] dark:text-[#a0dbbf] flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-sm font-extrabold text-[#18372b] dark:text-[#e7eee9]">
                سامانه پایش و ارزیابی عملکرد اخبار و گزارشات فراجا
              </h1>
              <span className="text-[11px] text-gray-500 dark:text-gray-400">
                پنل مدیریت و مانیتورینگ متمرکز
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {onExitAdmin && (
              <button
                type="button"
                onClick={onExitAdmin}
                className="px-3 py-1.5 border border-gray-200 dark:border-[#22372c] bg-white dark:bg-[#111c16] text-xs font-semibold rounded-lg hover:bg-gray-50 dark:hover:bg-[#18291f] transition"
              >
                نمای ثبت گزارش
              </button>
            )}

            <button
              type="button"
              onClick={handleLogout}
              className="px-3 py-1.5 text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40 hover:bg-red-100 dark:hover:bg-red-950 rounded-lg flex items-center gap-1.5 transition font-bold"
            >
              <LogOut className="w-3.5 h-3.5" />
              خروج
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="max-w-7xl mx-auto px-4 flex gap-4 border-t border-gray-100 dark:border-[#22372c] text-xs font-bold">
          <button
            type="button"
            onClick={() => setTab('monitoring')}
            className={`py-2.5 border-b-2 flex items-center gap-1.5 transition ${
              tab === 'monitoring'
                ? 'border-[#244b3b] dark:border-[#347d61] text-[#244b3b] dark:text-[#a0dbbf]'
                : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            مانیتورینگ و کارتابل گزارش‌ها ({reportsList.length})
          </button>

          <button
            type="button"
            onClick={() => setTab('performance')}
            className={`py-2.5 border-b-2 flex items-center gap-1.5 transition ${
              tab === 'performance'
                ? 'border-[#244b3b] dark:border-[#347d61] text-[#244b3b] dark:text-[#a0dbbf]'
                : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-800'
            }`}
          >
            <Award className="w-4 h-4" />
            ارزیابی عملکرد افراد و رده‌ها ({reporterPerformance.length})
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-[#15221b] border border-[#e1e9e4] dark:border-[#22372c] rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between text-gray-500 dark:text-gray-400 text-xs font-bold mb-2">
              <span>کل گزارش‌های ثبتی</span>
              <FileText className="w-4 h-4 text-[#244b3b] dark:text-[#a0dbbf]" />
            </div>
            <div className="text-2xl font-extrabold text-[#18372b] dark:text-[#e7eee9]">
              {reportsList.length.toLocaleString('fa-IR')}
            </div>
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 block">
              ثبت‌شده با الگوریتم هوشمند
            </span>
          </div>

          <div className="bg-white dark:bg-[#15221b] border border-[#e1e9e4] dark:border-[#22372c] rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between text-gray-500 dark:text-gray-400 text-xs font-bold mb-2">
              <span>گزارش‌های جدید و بررسی‌نشده</span>
              <Clock className="w-4 h-4 text-amber-500" />
            </div>
            <div className="text-2xl font-extrabold text-amber-600 dark:text-amber-400">
              {reportsList.filter((r) => r.status === 'جدید').length.toLocaleString('fa-IR')}
            </div>
            <span className="text-[11px] text-gray-500 dark:text-gray-400 mt-1 block">
              نیاز به ارزیابی اولیه
            </span>
          </div>

          <div className="bg-white dark:bg-[#15221b] border border-[#e1e9e4] dark:border-[#22372c] rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between text-gray-500 dark:text-gray-400 text-xs font-bold mb-2">
              <span>رده‌ها و گزارشگران فعال</span>
              <Users className="w-4 h-4 text-[#244b3b] dark:text-[#a0dbbf]" />
            </div>
            <div className="text-2xl font-extrabold text-[#18372b] dark:text-[#e7eee9]">
              {reporterPerformance.length.toLocaleString('fa-IR')}
            </div>
            <span className="text-[11px] text-gray-500 dark:text-gray-400 mt-1 block">
              در سراسر استان‌های تحت پوشش
            </span>
          </div>

          <div className="bg-white dark:bg-[#15221b] border border-[#e1e9e4] dark:border-[#22372c] rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between text-gray-500 dark:text-gray-400 text-xs font-bold mb-2">
              <span>میانگین کیفیت داده‌های استخراجی</span>
              <TrendingUp className="w-4 h-4 text-emerald-500" />
            </div>
            <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
              ۹۴٪
            </div>
            <span className="text-[11px] text-gray-500 dark:text-gray-400 mt-1 block">
              تطابق با ۷ مرحله استاندارد
            </span>
          </div>
        </div>

        {/* TAB 1: MONITORING & REPORTS LIST */}
        {tab === 'monitoring' && (
          <div className="bg-white dark:bg-[#15221b] border border-[#e1e9e4] dark:border-[#22372c] rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-[#18372b] dark:text-[#e7eee9]">
                  کارتابل پایش و گزارش‌گیری متمرکز
                </h2>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                  بررسی، تغییر وضعیت و صدور نسخه رسمی PDF گزارشات
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={exportCsv}
                  className="px-3.5 py-2 bg-white dark:bg-[#111c16] border border-gray-200 dark:border-[#22372c] text-xs font-bold rounded-xl hover:bg-gray-50 flex items-center gap-1.5 transition"
                >
                  <Download className="w-4 h-4" />
                  خروجی اکسل / CSV
                </button>
              </div>
            </div>

            {/* Filter Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="جستجو در شناسه، متن، نام گزارشگر یا رده..."
                  className="w-full bg-[#fcfdfa] dark:bg-[#0e1612] border border-[#d9e3dd] dark:border-[#284235] rounded-xl pl-9 pr-3 py-2 text-xs text-[#18372b] dark:text-[#e7eee9] focus:outline-none focus:ring-2 focus:ring-[#244b3b]"
                />
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              </div>

              <div>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full bg-[#fcfdfa] dark:bg-[#0e1612] border border-[#d9e3dd] dark:border-[#284235] rounded-xl px-3 py-2 text-xs text-[#18372b] dark:text-[#e7eee9]"
                >
                  <option value="all">تمام وضعیت‌ها</option>
                  <option value="جدید">وضعیت: جدید</option>
                  <option value="در حال پیگیری">وضعیت: در حال پیگیری</option>
                  <option value="اقدام‌شده">وضعیت: اقدام‌شده</option>
                  <option value="مختومه">وضعیت: مختومه</option>
                </select>
              </div>

              <div>
                <select
                  value={provinceFilter}
                  onChange={(e) => setProvinceFilter(e.target.value)}
                  className="w-full bg-[#fcfdfa] dark:bg-[#0e1612] border border-[#d9e3dd] dark:border-[#284235] rounded-xl px-3 py-2 text-xs text-[#18372b] dark:text-[#e7eee9]"
                >
                  <option value="all">تمام استان‌ها</option>
                  {provinces.map((prov) => (
                    <option key={prov} value={prov}>
                      استان {prov}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Reports Table */}
            <div className="overflow-x-auto border border-gray-100 dark:border-[#22372c] rounded-xl">
              <table className="w-full text-right text-xs">
                <thead className="bg-[#f8fbf9] dark:bg-[#111c16] text-[#31493e] dark:text-[#a0dbbf] border-b border-gray-200 dark:border-[#22372c] font-bold">
                  <tr>
                    <th className="p-3">شناسه رهگیری</th>
                    <th className="p-3">موضوع و شرح کوتاه</th>
                    <th className="p-3">گزارش‌دهنده و رده</th>
                    <th className="p-3">تاریخ ثبت</th>
                    <th className="p-3">مستندات</th>
                    <th className="p-3">وضعیت اقدام</th>
                    <th className="p-3 text-center">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-[#22372c]">
                  {filteredReports.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-gray-400">
                        هیچ گزارشی مطابق با فیلترهای انتخابی یافت نشد.
                      </td>
                    </tr>
                  ) : (
                    filteredReports.map((rep) => (
                      <tr key={rep.id} className="hover:bg-gray-50/50 dark:hover:bg-[#1a2f24]/30 transition">
                        <td className="p-3 font-mono font-bold text-[#244b3b] dark:text-[#a0dbbf]" dir="ltr">
                          {rep.id}
                        </td>
                        <td className="p-3 max-w-xs">
                          <span className="font-bold block truncate">{rep.title || 'گزارش خبری انتظامی'}</span>
                          <span className="text-[11px] text-gray-500 dark:text-gray-400 truncate block">
                            {rep.text}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="font-semibold block">{rep.reporter?.name || '—'}</span>
                          <span className="text-[11px] text-gray-500 dark:text-gray-400 block">
                            {rep.reporter?.rank || '—'} ({rep.reporter?.province || 'تهران'})
                          </span>
                        </td>
                        <td className="p-3 font-mono text-[11px]">
                          {new Date(rep.created || Date.now()).toLocaleDateString('fa-IR')}
                        </td>
                        <td className="p-3">
                          {rep.files?.length ? (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#edf5f0] text-[#244b3b]">
                              {rep.files.length} فایل
                            </span>
                          ) : (
                            <span className="text-gray-400 text-[10px]">بدون فایل</span>
                          )}
                        </td>
                        <td className="p-3">
                          <select
                            value={rep.status || 'جدید'}
                            onChange={(e) => handleStatusChange(rep.id, e.target.value)}
                            className="text-xs p-1 rounded-lg border border-gray-200 dark:border-[#22372c] bg-white dark:bg-[#111c16] font-medium"
                          >
                            <option value="جدید">جدید</option>
                            <option value="در حال پیگیری">در حال پیگیری</option>
                            <option value="اقدام‌شده">اقدام‌شده</option>
                            <option value="مختومه">مختومه</option>
                          </select>
                        </td>
                        <td className="p-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setSelectedReportForPdf(rep)}
                              className="px-2.5 py-1 bg-[#244b3b] hover:bg-[#18372b] text-white rounded-lg text-[11px] font-bold flex items-center gap-1 transition"
                              title="مشاهده نسخه رسمی PDF"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              نسخه PDF
                            </button>
                            <button
                              type="button"
                              onClick={() => setSelectedReportDetails(rep)}
                              className="p-1 text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white rounded"
                              title="مشاهده جزئیات"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: PERFORMANCE EVALUATION */}
        {tab === 'performance' && (
          <div className="bg-white dark:bg-[#15221b] border border-[#e1e9e4] dark:border-[#22372c] rounded-2xl p-6 shadow-sm space-y-4">
            <div>
              <h2 className="text-base font-bold text-[#18372b] dark:text-[#e7eee9]">
                ارزیابی عملکرد افراد و رده‌های گزارشگر
              </h2>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                سنجش کیفی و کمی رده‌های انتظامی بر اساس دقت ثبت اطلاعات، پیوست مدارک و صحت اطلاعات
              </p>
            </div>

            <div className="overflow-x-auto border border-gray-100 dark:border-[#22372c] rounded-xl">
              <table className="w-full text-right text-xs">
                <thead className="bg-[#f8fbf9] dark:bg-[#111c16] text-[#31493e] dark:text-[#a0dbbf] border-b border-gray-200 dark:border-[#22372c] font-bold">
                  <tr>
                    <th className="p-3">نام گزارشگر</th>
                    <th className="p-3">عنوان رده / یگان</th>
                    <th className="p-3">استان</th>
                    <th className="p-3 text-center">تعداد گزارش‌ها</th>
                    <th className="p-3 text-center">گزارش‌های مستنددار</th>
                    <th className="p-3 text-center">شاخص کیفیت اطلاعات</th>
                    <th className="p-3 text-center">ارزیابی عملکرد</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-[#22372c]">
                  {reporterPerformance.map((item, idx) => (
                    <tr key={idx} className="hover:bg-gray-50/50 dark:hover:bg-[#1a2f24]/30">
                      <td className="p-3 font-bold">{item.name}</td>
                      <td className="p-3 text-gray-600 dark:text-gray-300">{item.rank}</td>
                      <td className="p-3">{item.province}</td>
                      <td className="p-3 text-center font-mono font-bold">{item.reportsCount}</td>
                      <td className="p-3 text-center font-mono">{item.hasFilesCount}</td>
                      <td className="p-3 text-center">
                        <div className="inline-flex items-center gap-1 font-mono font-bold text-emerald-600">
                          <span>{item.avgQuality}٪</span>
                        </div>
                      </td>
                      <td className="p-3 text-center">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            item.rankBadge === 'عالی'
                              ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                              : 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300'
                          }`}
                        >
                          {item.rankBadge}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Official PDF Report Viewer Modal */}
      {selectedReportForPdf && (
        <OfficialPdfReport
          report={selectedReportForPdf}
          onClose={() => setSelectedReportForPdf(null)}
          isModal={true}
        />
      )}

      {/* Raw Details Modal */}
      {selectedReportDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-arrive">
          <div className="bg-white dark:bg-[#15221b] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-300 dark:border-[#22372c] text-right space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-gray-200 dark:border-[#22372c]">
              <h3 className="text-sm font-bold text-[#18372b] dark:text-[#e7eee9]">
                جزئیات گزارش {selectedReportDetails.id}
              </h3>
              <button
                type="button"
                onClick={() => setSelectedReportDetails(null)}
                className="text-gray-400 hover:text-gray-700 p-1"
              >
                ✕
              </button>
            </div>

            <div className="text-xs space-y-2 text-[#31493e] dark:text-[#c5d6cc]">
              <div>
                <strong>متن اولیه: </strong>
                <p className="p-2.5 bg-gray-50 dark:bg-[#0e1612] rounded-xl whitespace-pre-wrap mt-1">
                  {selectedReportDetails.text}
                </p>
              </div>
              <div>
                <strong>اطلاعات گزارش‌دهنده: </strong>
                <span>
                  {selectedReportDetails.reporter?.name} / {selectedReportDetails.reporter?.rank} (
                  {selectedReportDetails.reporter?.mobile})
                </span>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-gray-200 dark:border-[#22372c]">
              <button
                type="button"
                onClick={() => setSelectedReportDetails(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-[#111c16] rounded-xl text-xs font-bold"
              >
                بستن
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
